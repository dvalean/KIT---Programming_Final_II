package edu.kit.informatik.model.abilities;

public enum AbilityAction {
    ATTACK,
    REFLECT,
    DEFEND,
    BUFF
}
