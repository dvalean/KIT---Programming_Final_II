package edu.kit.informatik.model.characters.monster;

public enum MonsterTypes {
    BOSS,
    BLITZ,
    ICE,
    WATER,
    FIRE;
}
